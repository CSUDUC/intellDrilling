import pandas as pd
import os

path = "./results/"
files = os.listdir(path)
print("files:"files)
csv_list = []
for f in files:
    if os.path.splitext(f)[1] == '.csv':
        csv_list.append(path + '\\' + f)
    else:
        pass
df = pd.read_csv(csv_list[0], low_memory=False)
for i in range(1, len(csv_list)):
    df_i = pd.read_csv(csv_list[i], low_memory=False)
    pieces = [df[:], df_i[:]]
    df = pd.concat(pieces).drop_duplicates()
print("******************df:", df)
df = df.iloc[:, [1, 6, 7]]  #column, start from 0
df.to_csv(path +'\\csv_merge.csv', index=None, encoding='gbk')
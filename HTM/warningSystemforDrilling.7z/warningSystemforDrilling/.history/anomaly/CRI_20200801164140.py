import pandas as pd
import os

path = "./results/"
outfile = "CRI.csv"


files = os.listdir(path)
print("#################files:", files)

csv_list = []
for f in files:
    if os.path.splitext(f)[1] == '.csv':
        csv_list.append(path + '\\' + f)
    else:
        pass

df = pd.read_csv(csv_list[0], low_memory=False)
for i in range(1, len(csv_list)):
    df_i = pd.read_csv(csv_list[i], low_memory=False)
    # print("******************df_i:", df_i)
    pieces = [df[:], df_i[:]]
    # print("******************pieces:", pieces)
    df = pd.concat(pieces, axis = 1)
print("******************df:", df)
# df = df.iloc[:, [0,1,3,7,8,9]]  #column, start from 0
df.to_csv('csv_merge.csv', index=None, encoding='gbk')


# import pandas as pd
# import glob,os,sys
# input_path='./results'
# output_fiel='CRI.csv'
# all_files=glob.glob(os.path.join(input_path,'sales_*'))
# all_data_frames=[]
# for file in all_files:
#   data_frame=pd.read_csv(file,index_col=None)
#   total_sales=pd.DataFrame([float(str(value).strip('$').replace(',','')) for value in data_frame.loc[:,'Sale Amount']]).sum()
#   average_sales=pd.DataFrame([float(str(value).strip('$').replace(',','')) for value in data_frame.loc[:,'Sale Amount']]).mean()
#   data={
#     'filename':os.path.basename(file),
#     'total_sales':total_sales,
#     'average_sales':average_sales
#   }
#   all_data_frames.append(pd.DataFrame(data,columns=['filename','total_sales','average_sales']))
# data_frame_concat=pd.concat(all_data_frames,axis=0,ignore_index=True)
# data_frame_concat.to_csv(output_fiel,index=False)
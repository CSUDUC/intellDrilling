import pandas
import glob
import os

def mergeData(indir="dir/path", outdir="dir/path"):
    dfs = []
    os.chdir(indir)
    fileList=glob.glob("*.txt")
    for filename in fileList:
        left= "/path/filename.csv"
        right = filename
        output = "/path/filename.csv"
        leftDf = pandas.read_csv(left)
        rightDf = pandas.read_csv(right)
        mergedDf = pandas.merge(leftDf,rightDf,how='right',on="Alpha", sort=True)
        dfs.append(mergedDf)
    outputDf = pandas.concat(dfs, ignore_index=True)
    #add missing rows from leftDf (in sample Alpha - 0.25) 
    #fill NaN values by 0
    outputDf = pandas.merge(leftDf,outputDf,how='left',on="Alpha", sort=True).fillna(0)
    #columns are converted to int
    outputDf[['Beta', 'Charlie']] = outputDf[['Beta', 'Charlie']].astype(int) 
    print (outputDf)

    outputDf.to_csv(output, index=0)

mergeData()
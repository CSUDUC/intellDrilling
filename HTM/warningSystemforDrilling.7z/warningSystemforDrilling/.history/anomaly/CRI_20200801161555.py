import os
import pandas as pd
import glob
csv_list = glob.glob('./14 points/*') #查看同文件夹下的csv文件数
print(u'%s '% len(csv_list))
print(u'正在处理............')
for i in csv_list: #循环读取同文件夹下的csv文件
    fr = open(i,'rb').read()
    with open('result.csv','ab') as f: #将结果保存为result.csv
        f.write(fr)
print(u'合并完毕！')
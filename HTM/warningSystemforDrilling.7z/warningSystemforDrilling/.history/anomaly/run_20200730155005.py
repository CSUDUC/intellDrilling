"""
Groups together code used for creating a NuPIC model and dealing with IO.
(This is a component of the Drilling Anomaly Tutorial.)
"""
import importlib
import sys
import csv
import datetime

from nupic.data.inference_shifter import InferenceShifter
from nupic.frameworks.opf.model_factory import ModelFactory

import nupic_anomaly_output


DESCRIPTION = (
  "Starts a NuPIC model from the model params returned by the swarm\n"
  "and pushes each line of input from the drilling into the model. Results\n"
  "are written to an output file (default) or plotted dynamically if\n"
  "the --plot option is specified.\n"
)
# attrs_NAME = "rec-center-hourly"
attrs_NAME = "hkla"
DATA_DIR = "./driling_data/"
# MODEL_PARAMS_DIR = "./model_params"
# '7/2/10 0:00'
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"



def createModel(modelParams):
  """
  Given a model params dictionary, create a CLA Model. Automatically enables
  inference for kw_energy_consumption.
  :param modelParams: Model params dict
  :return: OPF Model object
  """
  model = ModelFactory.create(modelParams)
  model.enableInference({"predictedField": "hkla"})
  return model


def getModelParamsFromName(attrName):
  """
  Given a attr name, assumes a matching model params python module exists within
  the model_params directory and attempts to import it.
  :param attrName: attr name, used to guess the model params module name.
  :return: OPF Model params dictionary
  """
  importName = "model_params.%s_model_params" % (
    attrName.replace(" ", "_").replace("-", "_")
  )
  print "Importing model params from %s" % importName
  try:
    importedModelParams = importlib.import_module(importName).MODEL_PARAMS
    # steps = importedModelParams['modelParams']['clParams']['steps']
    # print "mparams is %s ...." % steps
  except ImportError:
    raise Exception("No model params exist for '%s'. Run swarm first!"
                    % attrName)
  return importedModelParams

def getAttrFromModelParams(importedModelParams):

  steps = importedModelParams['modelParams']['clParams']['steps']

  return steps


def runIoThroughNupic(inputData, model, steps, attrName, plot):
  """
  Handles looping over the input data and passing each row into the given model
  object, as well as extracting the result object and passing it into an output
  handler.
  :param inputData: file path to input data CSV
  :param model: OPF Model object
  :param attrName: attr name, used for output handler naming
  :param plot: Whether to use matplotlib or not. If false, uses file output.
  """
  inputFile = open(inputData, "rb")
  print inputFile
  csvReader = csv.reader(inputFile)
  # skip header rows
  csvReader.next()
  csvReader.next()
  csvReader.next()

  shifter = InferenceShifter()
  if plot:
    output = nupic_anomaly_output.NuPICPlotOutput(attrName)
  else:
    output = nupic_anomaly_output.NuPICFileOutput(attrName)

  counter = 0
  for row in csvReader:
    counter += 1
    if (counter % 1000 == 0):
      print "Read %i lines..." % counter
    timestamp = datetime.datetime.strptime(row[0], DATE_FORMAT)
    attr = float(row[1])
    # print "attr is %f ..." % attr
    result = model.run({
      "timestamp": timestamp,
      "hkla": attr
    })

    if plot:
      result = shifter.shift(result)
    print steps
    prediction = result.inferences["multiStepBestPredictions"]["%i"] % steps
    print prediction
    anomalyScore = result.inferences["anomalyScore"]
    output.write(timestamp, attr, prediction, anomalyScore)

  inputFile.close()
  output.close()



def runModel(attrName, plot=False):
  """
  Assumes the gynName corresponds to both a like-named model_params file in the
  model_params directory, and that the data exists in a like-named CSV file in
  the current directory.
  :param attrName: Important for finding model params and input CSV file
  :param plot: Plot in matplotlib? Don't use this unless matplotlib is
  installed.
  """
  print "Creating model from %s..." % attrName
  modelParams = getModelParamsFromName(attrName)
  model = createModel(modelParams)
  steps = getAttrFromModelParams(modelParams)
  print steps
  inputData = "%s/%s.csv" % (DATA_DIR, attrName.replace(" ", "_"))
  
  runIoThroughNupic(inputData, model, steps, attrName, plot)



if __name__ == "__main__":
  print DESCRIPTION
  plot = False
  args = sys.argv[1:]
  if "--plot" in args:
    plot = True
  runModel(attrs_NAME, plot=plot)


# coding: utf-8
import os
import re
 
 
def parserln(ln, patt):
    """用给定的正则表达式解析行"""
    matched = patt.match(ln)
    if matched:
        return matched.groupdict()
 
 
def getdata(filename, parser, callback=None):
    """用指定的解析方du法parser解析指定文件,
        用callback进行数据加工zhi过的数据列表
    """
    with open(filename, 'rt') as handle:
        return map(
            callback,
            filter(None, map(parser, handle))
            )
 
 
def storage(filename, dataserial, spliter=','):
    """将数据序dao列按行存储到指定文件,
        每一序列元素间用指定的字符分割"""
    with open(filename, 'wt') as handle:
        handle.writelines([
            "%s\n" % (spliter.join(map(str, item)))
            for item in dataserial
        ])
 
 
if __name__ == "__main__":
    patt = re.compile(
        r"""^
        (?P<month>\d+),
        (?P<amount>\d+),
        (?P<usage>\d+)
        \s*$""",
        re.I | re.U | re.X)
    datapath = 'datasource'
    # datasource下所有存在"usage.csv"文件的子目录
    subpaths = [
        os.path.join(datapath, path)
        for path in os.listdir(datapath)
        if (os.path.isdir(os.path.join(datapath, path))
            and os.path.exists(
                os.path.join(datapath, path, "usage.txt"))
            )
        ]
    storage(
        'store.csv',
        zip(*map(
            lambda path: getdata(
                os.path.join(path, "usage.csv"),
                # 解析方法为用patt解析行
                parser=lambda ln: parserln(ln, patt),
                # 数据加工方法是取出"amount"转成整数
                callback=lambda x: int(x["amount"]),
            ),
            subpaths))
        )
import os
import pandas as pd
import glob
csv_list = glob.glob('./resules/*') 
print(u'%s files'% len(csv_list))
print(u'P............')
for i in csv_list: 
    fr = open(i,'rb').read()
    with open('result.csv','ab') as f: 
        f.write(fr)
print(u'#############！')